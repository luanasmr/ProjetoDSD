const express = require('express');
const app = express();
const cors = require('cors');
require('dotenv/config'); // acessar variáveis de ambiente
var timeout = require('connect-timeout');



//milldewares

app.use(express.json());
app.use(express.urlencoded({extended: false}));
// app.use((req, res, next)=>{
//     res.header("Access-control-Allow-Origin", "*");
//     res.header("Access-Control-Allow-Methods", 'GET,PUT,POST,DELETE');
//     res.header('Access-Control-Allow-Headers', 'Content-Type, X-Custom-Header');
//     res.header("Access-control-Allow-Headers", "Origin, X-Requested-With", "Content-Type","Accept");
    // next();

// });
app.use(cors());

//routes
app.use(require('./routes/index'));
app.use(timeout(120000));
app.use(haltOnTimedout);

function haltOnTimedout(req, res, next){
  if (!req.timedout) next();
}


app.listen(process.env.PORT || 1335);
console.log('Servidor na porta:',1335);


